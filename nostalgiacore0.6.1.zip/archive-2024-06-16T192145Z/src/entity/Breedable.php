<?php

interface Breedable{
	public function spawnChild();
	
	public function isInLove();
}