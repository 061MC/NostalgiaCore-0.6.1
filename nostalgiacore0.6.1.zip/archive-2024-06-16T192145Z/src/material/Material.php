<?php
/*value - durability*/
class Material{
	const LEATHER = 5; //when enums
	const CHAIN = 15;
	const GOLD = 7;
	const IRON = 15;
	const DIAMOND = 33;
}