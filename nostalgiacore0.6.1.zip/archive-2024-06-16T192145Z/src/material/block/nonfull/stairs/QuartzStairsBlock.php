<?php

class QuartzStairsBlock extends StairBlock{
	public function __construct($meta = 0){
		parent::__construct(QUARTZ_STAIRS, $meta, "Quartz Stairs");
	}
	
}