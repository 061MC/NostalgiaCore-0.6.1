<?php

/**
 * Events that can be cancelled must use the interface CancellableEvent
 */

interface CancellableEvent{

}